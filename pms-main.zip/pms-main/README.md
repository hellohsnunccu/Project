# pms

## package

- python-decouple 
    make python to read .env file
- whitenoise 
    dealwith static file, 

